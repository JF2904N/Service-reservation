
public interface ItemFactory {
	Item createItem();
}
