
public interface Item {
	String getInfo();
}
